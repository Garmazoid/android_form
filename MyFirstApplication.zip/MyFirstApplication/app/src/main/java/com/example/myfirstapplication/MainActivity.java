package com.example.myfirstapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText input1;
    private EditText input2;
    private Button calculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inputs);


        input1 = findViewById(R.id.input1);
        input2 = findViewById(R.id.input2);


        calculate = findViewById(R.id.calculate);
        calculate.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                String num1 = input1.getText().toString();
                String num2 = input2.getText().toString();
                String res = "" + Integer.parseInt(num1) + Integer.parseInt(num2);
                Toast.makeText(getApplicationContext(), "Result: " + res, Toast.LENGTH_LONG).show();
            }
        });
    }

    /*
    public void showToast(View view){
        String text = editText.getText().toString();
        if(!text.isEmpty()) {
            Toast.makeText(this, text, Toast.LENGTH_LONG).show();
        }
    }
    */
}